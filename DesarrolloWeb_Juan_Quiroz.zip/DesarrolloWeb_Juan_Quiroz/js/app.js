var totalPuntos = 0;
var numeroMovimientos =0;
var cantidadDeClicks = 0;
var tiempoTranscurrido = {
  minutos:2,
  segundos:0
}

/*Funciones*/
/*Cambia color de título a Blanco*/
function tituloBlanco(titulo){
  titulo.animate({
    color:"white"
  },500, function(){tituloAmarillo(titulo)})
}
/*Cambia color de título a Amarillo*/
function tituloAmarillo(titulo){
  titulo.animate({
    color:"yellow"
  },500, function(){tituloBlanco(titulo)})
}

/*Evento clic para iniciar y reiniciar el finalizaJuego
permite llevar un control del tiempo */
$('.btn-reinicio').click(function startTimer()
{
  if($(".btn-reinicio").text()=="Iniciar"){
      $(".btn-reinicio").text("Reiniciar");
    tiempo_corriendo = setInterval(function(){
      if(tiempoTranscurrido.minutos == 0 && tiempoTranscurrido.segundos == 00){
        //Se ejecuta la funcion que termine el juego.
        finalizaJuego();
      }

      if(tiempoTranscurrido.segundos==0){
        tiempoTranscurrido.segundos = 59;
        tiempoTranscurrido.minutos--;
      }

      tiempoTranscurrido.segundos--;
      $("#timer").text(tiempoTranscurrido.minutos+":"+tiempoTranscurrido.segundos);

      }, 1000);
    }else {
      clearInterval(tiempo_corriendo);
      $(".btn-reinicio").text("Iniciar");
    }

  /*Se comienza la animación para el título*/
  tituloBlanco($(".main-titulo"));
  /*Se ejecuta funcion para cargar el juego*/
  juegoIniciado();
});

/*Funcion ejecuta la carga del juego*/
function juegoIniciado()
{
  cantidadDeClicks++;
  if(cantidadDeClicks==1)
  {
    $('.btn-reinicio').text('Reiniciar');
    prepararTablero();
    startTimer();
    luegoDeJugar();
  }
  else
  {
    location.reload();
  }
}

/*Se llenan todas las casilas del tablero para agregar los dulces*/
function prepararTablero()
{
  var columna;
  for (var x = 1; x <= 7; x++)
  {
    columna = ".col-"+x;
    llenarDulces($(columna), 7);
  }
}

/*Funcion que llena los dulces aleatoriamente en el tablero y asigna las propiedades
para sus movimientos y animaciones*/
function llenarDulces(columna, espacios)
{
  for (var i = 0; i < espacios; i++)
  {
    var dulce = document.createElement("img");
    $(dulce)
    .attr("src", obtenerRuta())
    .addClass("elemento")
    .draggable(
      {
        grid: [120,90],
        revert: "valid"
      })
    .droppable(
      {
        accept: ".elemento",
        drop: function(event, ui)
        {
          var srcFrom = $(this).attr("src");
          var srcTo = $(ui.draggable).attr("src");
          $(this).attr("src", srcTo);
          $(ui.draggable).attr("src", srcFrom);
          window.setTimeout(luegoDeJugar, 500);
          sumarMovimiento();
        }
      })
    $(columna).prepend(dulce);
  }
}

/*Funcion que suministra una ruta aleatoria para cada dulce*/
function obtenerRuta(){
  var sources = ['./image/1.png', './image/2.png', './image/3.png', './image/4.png'];
  return sources[obtenerNumeroAleatorio()]
}

/*Funcion que genera un numero aleatorio*/
function obtenerNumeroAleatorio()
{
  return Math.floor(Math.random() * 3);
}

/*Funcion que termina eliminando los elementos de acuerdo a sus combinaciones y poblar con
mas dulces los espacios faltantes*/

function luegoDeJugar()
{
  validarCombinacion();
  window.setTimeout(eliminaDulces,2100);
  window.setTimeout(llenarDulceXTurno, 2200);
}

/*Recorre cada uno de los espacios verificando si existe 3 o mas dulces iguales para su eliminacion*/
function validarCombinacion()
{
  var dulceAComparar;
  var dulceActual;
  var matchLeft, matchRight, matchDown, matchUp = false;

  for (var columna = 1; columna <= 7; columna++)
  {
    for (var fila = 0; fila < 7; fila++)
    {
      matchUp=matchDown=matchRight=matchLeft=false;
      dulceActual = $(".col-"+columna).find("img")[fila]

      //Verfica Izquierda
      if($(".col-"+(columna-1)).length > 0)
      {
        //Verifica dulce a la izquierda
        dulceAComparar = $(".col-"+(columna-1)).find("img")[fila]
        if (verificaDosDulcesIguales(dulceActual, dulceAComparar))
        {
          matchLeft = true;
          if($(".col-"+(columna-2)).length > 0)
          {
            //Verifica dos columnas a la izquierda
            dulceAComparar = $(".col-"+(columna-2)).find("img")[fila]
            if(verificaDosDulcesIguales(dulceActual, dulceAComparar))
            {
              adicionarPunto(dulceActual, $(".col-"+(columna-1)).find("img")[fila], dulceAComparar)
            }
          }
        }
      }

      //Verificacion Derecha
      if($(".col-"+(columna+1)).length > 0)
      {
        //Verifica dulce a la izquierda
        dulceAComparar = $(".col-"+(columna+1)).find("img")[fila]
        if (verificaDosDulcesIguales(dulceActual, dulceAComparar))
        {
          matchRight = true;
          if($(".col-"+(columna+2)).length > 0)
          {
            //Verifica dos columnas a la izquierda
            dulceAComparar = $(".col-"+(columna+2)).find("img")[fila]
            if(verificaDosDulcesIguales(dulceActual, dulceAComparar))
            {
              adicionarPunto(dulceActual, $(".col-"+(columna+1)).find("img")[fila], dulceAComparar)
            }
          }
        }
      }

      //Verificacion dulces a izquierda y Derecha
      if (matchLeft == true && matchRight == true)
      {
        adicionarPunto(dulceActual, $(".col-"+(columna-1)).find("img")[fila], $(".col-"+(columna+1)).find("img")[fila])
      }

      //Verifica arriba
      if($(".col-"+columna).find("img")[fila-1])
      {
        //Verifica dulce arriba
        dulceAComparar = $(".col-"+columna).find("img")[fila-1]
        if (verificaDosDulcesIguales(dulceActual, dulceAComparar))
        {
          matchUp = true;
          if($(".col-"+columna).find("img")[fila-2])
          {
            //Verifica dos filas hacia arriba
            dulceAComparar = $(".col-"+columna).find("img")[fila-2]
            if(verificaDosDulcesIguales(dulceActual, dulceAComparar))
            {
              adicionarPunto(dulceActual, $(".col-"+columna).find("img")[fila-1], dulceAComparar)
            }
          }
        }
      }
      //Verifica abajo
      if($(".col-"+columna).find("img")[fila+1])
      {
        //Verifica dulce abajo
        dulceAComparar = $(".col-"+columna).find("img")[fila+1]
        if (verificaDosDulcesIguales(dulceActual, dulceAComparar))
        {
          matchDown = true;
          if($(".col-"+columna).find("img")[fila+2])
          {
            //Verifica dos filas hacia abajo
            dulceAComparar = $(".col-"+columna).find("img")[fila+2]
            if(verificaDosDulcesIguales(dulceActual, dulceAComparar))
            {
              adicionarPunto(dulceActual, $(".col-"+columna).find("img")[fila+1], dulceAComparar)
            }
          }
        }
      }
      //Verificacion Arriba y Abajo
      if (matchUp == true && matchDown == true)
      {
        adicionarPunto(dulceActual, $(".col-"+columna).find("img")[fila+1], $(".col-"+columna).find("img")[fila-1])
      }
    }
  }
}

/*Se realiza la comparación de dos dulces para determinar si son iguales*/
function verificaDosDulcesIguales(dulceUno, dulceDos)
{
  //Se compara la ruta
  if ($(dulceUno).attr("src")==$(dulceDos).attr("src"))
  {
    return true;
  }
  else return false;
}

/*Se adicionan los puntos y se esconde la linea de dulces*/
function adicionarPunto(dulceUno, dulceDos, dulceTres)
{
  $("#score-text").text(totalPuntos += 10);
  $(dulceUno).hide('pulsate', 2000)
  $(dulceDos).hide('pulsate', 2000)
  $(dulceTres).hide('pulsate', 2000)
}

/*Elimina los dulces*/
function eliminaDulces()
{
  $("img:hidden").each(function(index)
  {
    $(this).remove()
  })
}

/*Se llena con dulces los espacios que fueron removidos*/
function llenarDulceXTurno()
{
  var numeroElementos = numeroFalta = 0;
  for (var i = 1; i <= 7; i++)
  {
    numeroElementos=$(".col-"+i).find("img").length;
    numeroFalta = 7 - numeroElementos;
    llenarDulces($(".col-"+i), numeroFalta);
  }
  window.setTimeout(luegoDeJugar, 500)
}

/*Realiza la suma de un número*/
function sumarMovimiento()
{
  $('#movimientos-text').text(numeroMovimientos++);
}

/*Se reorganiza la pantalla luego de finalizar el juego*/
function finalizaJuego()
{
  $('.panel-tablero').hide(900);
  $('.panel-score')
  .animate({
    width: '100%'
  }, 1000, function()
    {
      $(this).prepend("<h2 class='titulo-over'>The End</h2>")
    })
  $('.time').hide(500)
  $('#score-text').hide()
  $('.score').append("<span class='data-info' id='score-final'>"+totalPuntos+"</span>")
}

function startTimer(tiempoDuracion, display) {
    var timer = tiempoDuracion, tiempoMinutos, tiempoSegundos;
    var interval= setInterval(function () {
        tiempoMinutos = parseInt(timer / 60, 10)
        tiempoSegundos = parseInt(timer % 60, 10);

        tiempoMinutos = tiempoMinutos < 10 ? "0" + tiempoMinutos : tiempoMinutos;
        tiempoSegundos = tiempoSegundos < 10 ? "0" + tiempoSegundos : tiempoSegundos;

        $(display).text(tiempoMinutos + ":" + tiempoSegundos);

        if (--timer < 0) {
            $("body").trigger("finTiempo");
						clearInterval(interval)
        }
    }, 1000);
}
